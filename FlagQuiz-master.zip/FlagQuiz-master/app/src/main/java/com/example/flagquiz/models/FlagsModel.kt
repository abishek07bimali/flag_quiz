package com.example.flagquiz.models

data class FlagsModel(val id: Int,
                      val countryName: String,
                      val flagName: String) {

}